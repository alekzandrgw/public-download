<?php

/**
 * @package   Duplicator
 * @copyright (c) 2022, Snap Creek LLC
 */

defined("ABSPATH") or die("");
?>
<i class="fa fa-exclamation-triangle fa-sm"></i>
<?php
    esc_html_e('No selections made! Please select an action from the "Bulk Actions" drop down menu!', 'duplicator-pro');
?>
