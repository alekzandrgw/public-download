<?php

/**
 * @package   Duplicator
 * @copyright (c) 2022, Snap Creek LLC
 */

defined("ABSPATH") or die("");
?>
<i class="fa fa-exclamation-triangle fa-sm"></i>
<?php
    esc_html_e('No selections made! Please select at least one Backup to delete!', 'duplicator-pro');
?>
