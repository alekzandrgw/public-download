<?php
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?><div class="dup-pro-recovery-message" >
    <p class="recovery-reset-message-ok">
        <?php _e('The Recovery Point has been reset, all previously copied Recovery URLs are no longer valid.', 'duplicator-pro'); ?>
    </p>
</div>