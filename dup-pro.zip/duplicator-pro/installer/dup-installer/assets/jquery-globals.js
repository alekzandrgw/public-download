import jquery from "jquery";

window.$ = window.jQuery = jquery;
