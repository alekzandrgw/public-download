<?php
/**
 * Plugin Name: Rapyd Helper 
 * Description: Must-Use plugin for integration into the Rapyd dashboard.
 * Version: 1.2.4.1
 * Author: Rapyd
 * Author URI:  https://rapyd.cloud
 *
 * @package RAPYD
 */

require dirname( __FILE__ ) . '/rapyd-includes/vendor/autoload.php';

Rapyd::instance(); // Execute the Rapyd 🔥

