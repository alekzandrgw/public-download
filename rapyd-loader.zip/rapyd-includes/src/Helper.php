<?php

namespace Rapyd;

class Helper
{

    private static $instance;

    /**
     * Do not call a any other function inside the construct of this class.
     */
    public function __construct()
    {
    }

    /**
     * Return the Instance.
     * Do not call a any other function inside the instance of this class.
     * @return Helper
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class          = __CLASS__;
            self::$instance = new $class;
        }

        return self::$instance;
    }

    /**
     * Helper function to securely encrypt the rapyd data file.
     * @param $data
     * @param $key
     *
     * @return string
     */
    public function encryptRapyd($rawData)
    {
        $rapydCertPublic  = dirname(__DIR__) . '/rapyd-public.key';
        $secretKey = random_bytes(20);
        $publicKey = file_get_contents($rapydCertPublic);
        openssl_public_encrypt($secretKey, $encryptedKey, $publicKey);

        $data = array();
        $data['identifier'] = base64_encode($encryptedKey);

        $encryptionKey = base64_decode($secretKey);
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        $encrypted = openssl_encrypt($rawData, 'aes-256-cbc', $encryptionKey, 0, $iv);
        $data['payload'] = base64_encode($encrypted . '::' . $iv);

        return $data;
    }
}
