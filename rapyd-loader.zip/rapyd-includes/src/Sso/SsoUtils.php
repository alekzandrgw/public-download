<?php
namespace Rapyd\Sso;

use WP_User;
use Exception;

class SsoUtils
{
    private static $instance;
    public const TOKEN_USER_META = 'rapyd_secure_login_token';
    public const SETTING_OPTION = 'rapyd_secure_login_token_settings';
    public const CRON_HOOK_NAME = 'wpcli_token_login_cleanup_expired_tokens';

    public function __construct()
    {
    }

    /**
     * @return SsoUtils
     */
    public static function instance()
    {
        if ( ! isset(self::$instance) ) {
            $class          = __CLASS__;
            self::$instance = new $class;
        }

        return self::$instance;
    }

    /**
     * Get settings with defaults
     * @return array     
     */
    public function getSettings()
    {
        $defaults = [
            'token_ttl'      => 15,
            'token_validity' => 1,
            'token_interval' => 'MINUTE',
            'default_role'   => 'editor',
        ];

        $settings = get_option(self::SETTING_OPTION, []);
        $settings = wp_parse_args($settings, $defaults);

        return $settings;
    }
    
    /**
     * Parse the endpoint & key from the URI, if any.
     *
     * @param $uri string  Request URI
     *
     * @return array [endpoint, key]
     */
    public static function parseUri( $uri )
    {
        $segments = explode('|', $uri);

        // If there aren't at least 2 segments,
        // return empty values to always return an array with the same length.
        if ( count($segments) < 2 ) {
            return [ '', '' ];
        }

        return array_slice($segments, -2);
    }
    
    /**
     * Create token
     *
     * @param object $user \WP_User object
     *
     * @return string
     */
    public function createUserToken( WP_User $user )
    {
        $settings     = $this->getSettings();
        $tokens       = get_user_meta($user->ID, self::TOKEN_USER_META, true);
        $tokens       = is_string($tokens) ? array( $tokens ) : $tokens;
        $newToken    = sha1(wp_generate_password());
        $hashedToken = hash_hmac('sha256', $newToken, wp_salt());

        $cip = $_SERVER['REMOTE_ADDR'];
        $ip  = sha1($cip);
        if ( defined('WP_CLI') && WP_CLI ) {
            $ip = 'cli';
        }

        $tokens[] = [
            'rapyd-secure-login'   => $hashedToken,
            'time'    => time(),
            'ip_hash' => $ip,
        ];

        update_user_meta($user->ID, self::TOKEN_USER_META, $tokens);

        if ( absint($settings['token_ttl']) > 0 ) { // token
            wp_schedule_single_event(time() + ($settings['token_ttl'] * MINUTE_IN_SECONDS), self::CRON_HOOK_NAME, array( $user->ID ));
        }

        return $newToken;
    }

    /**
     * Create the Secure Auto Login Endpoint.
     *
     * @param object $user WP_User object
     *
     * @return mixed|string
     */
    public function createLoginLink( WP_User $user )
    {
        $token = $this->createUserToken($user);

        $query_args = array(
            'rapyd-secure-login'             => $user->ID .'|'. $token,
        );

        if ( ! empty($_POST['redirect_to']) ) {
            $query_args['redirect_to'] = esc_url_raw($_POST['redirect_to']);
        }

        $login_url = esc_url_raw(add_query_arg($query_args, wp_login_url()));

        return $login_url;
    }


    /**
     * Get the token of the user.
     *
     * @param int  $userId       User ID
     * @param bool $clear_expired flag for clean-up expired tokens
     *
     * @return array|mixed
     */
    public function getUserTokens( $userId, $clear_expired = false )
    {
        $tokens = get_user_meta($userId, self::TOKEN_USER_META, true);
        $tokens = is_array($tokens) ? $tokens : [];

        if ( $clear_expired ) {
            $settings = $this->getSettings();
            $ttl      = absint($settings['token_ttl']);

            if ( 0 === $ttl ) { // means token lives forever till used
                return $tokens;
            }

            foreach ( $tokens as $index => $token_data ) {
                if ( empty($token_data) ) {
                    unset($tokens[$index]);
                    continue;
                }

                if ( time() > absint($token_data['time']) + ($ttl * MINUTE_IN_SECONDS) ) {
                    unset($tokens[$index]);
                }
            }
            update_user_meta($userId, self::TOKEN_USER_META, $tokens);
        }

        return $tokens;
    }

    /**
     * Get default redirect url for given user
     *
     * @param \WP_User $user User object
     *
     * @return string|void
     */
    public function getUserDefaultRedirect( WP_User $user )
    {
        if ( is_multisite() && ! get_active_blog_for_user($user->ID) && ! is_super_admin($user->ID) ) {
            $redirect_to = user_admin_url();
        }
        elseif ( is_multisite() && ! $user->has_cap('read') ) {
            $redirect_to = get_dashboard_url($user->ID);
        }
        elseif ( ! $user->has_cap('edit_posts') ) {
            $redirect_to = $user->has_cap('read') ? admin_url('profile.php') : home_url();
        }
        else {
            $redirect_to = admin_url();
        }

        return $redirect_to;
    }

    /**
     * Delete all secure login tokens.
     */
    public function deleteAllTokens()
    {
        global $wpdb;

        return $wpdb->delete(
            $wpdb->usermeta,
            [
                'meta_key' => self::TOKEN_USER_META,
            ]
        );
    }
}
