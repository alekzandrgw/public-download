<?php

namespace Rapyd\Sso;

if (!defined('ABSPATH')) {
    return;
}

if (!function_exists('is_plugin_active')) {
    require_once ABSPATH . '/wp-admin/includes/plugin.php';
}

use Rapyd\Sso\SsoUtils;

class SsoCliLoader
{

    private static $instance;

    public function __construct()
    {
        // Load WP-CLI command if WP_CLI_Command class exists
        if (defined('WP_CLI') && WP_CLI) {
            // 🔥 Add the rapyd command to WordPress.
            \WP_CLI::add_command('rapyd', 'Rapyd\WpCli\Rapyd');
        }

        // Hook to handle auto login.
        add_action('init', array($this, 'handleAutoLogin'));
    }

    /**
     * @return SsoCliLoader
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class          = __CLASS__;
            self::$instance = new $class;
        }

        return self::$instance;
    }

    /**
     * Handle Rapyd Secure Auto Login Request.
     */
    public function handleAutoLogin()
    {
        $secureToken = isset($_GET['rapyd-secure-login']) ? $_GET['rapyd-secure-login'] : false;

        // Exit if no token is found in the Address URL.
        if (empty($secureToken)) {
            return;
        }

        // Extract the userId & token from $secureToken
        list($userId, $token) = SsoUtils::parseUri($secureToken);

        if (empty($userId) || empty($token)) {
            return;
        }

        $user  = get_user_by('id', (int) $userId);
        if (!$user) {
            wp_safe_redirect(wp_login_url());
            exit;
        }

        $settings       = SsoUtils::instance()->getSettings();
        $token_validity = $settings['token_validity'];

        $tokens        = SsoUtils::instance()->getUserTokens($user->ID, true);
        $is_valid      = false;
        $current_token = null;
        foreach ($tokens as $i => $token_data) {
            if (empty($token_data) || !is_array($token_data) || !isset($token_data['rapyd-secure-login'])) {
                unset($tokens[$i]);
                continue;
            }

            if (hash_equals($token_data['rapyd-secure-login'], hash_hmac('sha256', $token, wp_salt()))) {
                $is_valid          = true;
                $current_token     = $token_data;
                $token_usage_count = isset($token_data['usage_count']) ? absint($token_data['usage_count']) + 1 : 1;

                $tokens[$i]['usage_count'] = $token_usage_count;
                if (0 !== $token_validity && $token_validity <= $token_usage_count) {
                    unset($tokens[$i]);
                }

                break;
            }
        }

        if (!$is_valid) {
            wp_safe_redirect(wp_login_url());
            exit;
        }

        do_action('rapyd_secure_autoload_set_cookie_pre', $user, $current_token);

        update_user_meta($user->ID, SsoUtils::instance()::TOKEN_USER_META, $tokens);
        wp_set_auth_cookie($user->ID, true, is_ssl());

        do_action('rapyd_secure_autoload_set_cookie_post', $user, $current_token);

        /**
         * Some plugins integrated with core's wp_login hook.
         * So call it here too.
         *
         */
        do_action('wp_login', $user->user_login, $user);

        $default_redirect = SsoUtils::instance()->getUserDefaultRedirect($user);

        // Delete all tokens.
        SsoUtils::instance()->deleteAllTokens();

        wp_safe_redirect($default_redirect);
        exit;
    }
}
