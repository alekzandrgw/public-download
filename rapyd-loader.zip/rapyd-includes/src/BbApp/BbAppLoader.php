<?php

namespace Rapyd\BbApp;

class BbAppLoader
{

    private static $instance;

    public function __construct()
    {
    }

    /**
     * Instance of BbAppLoader
     * @return bbAppLoader
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class          = __CLASS__;
            self::$instance = new $class;
        }

        return self::$instance;
    }

    /**
     * Get the BuddyBoss App Information.
     * @return array
     */
    public function getAppInfo()
    {

        $data['bbapp_info'] = array();

        if (is_plugin_active('buddyboss-app/buddyboss-app.php')) {
            $data['bbapp_info'] = \BuddyBossApp\ManageApp::instance()->get_apps_data();
        }

        return $data;
    }

    /**
     * Get the BbApp Settings
     *
     * @return array
     */
    public function getAppSettings()
    {

        $data['bbapp_settings'] = array();

        if (is_plugin_active('buddyboss-app/buddyboss-app.php')) {
            $data['bbapp_settings'] = \BuddyBossApp\ManageApp::instance()->get_app_settings();
        }

        return $data;
    }

    /**
     * Return the Added Apple Devices.
     *
     * @return array
     */
    public function getAppleLocalDevices()
    {

        $data['bbapp_device_list'] = get_site_transient('bbapp_apple_get_local_devices');

        return $data;
    }


    /**
     * Check weather BuddyBoss App is activated as network mode.
     * @return bool
     */
    public function BbAppNetworkActivated()
    {
        if (is_plugin_active_for_network('buddyboss-app/buddyboss-app.php')) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Return the Build List of BuddyBoss App.
	 * @return array
	 */
	public function getAppBuildList() {

		$data['bb_app_build_list'] = array();

		if( is_plugin_active( 'buddyboss-app/buddyboss-app.php' ) ) {
			$data['bb_app_build_list'] = \BuddyBossApp\Build::instance()->get_app_builds( '', '', false, '', 1, 100 );
            if( isset( $data['bb_app_build_list']['data'] ) && ! empty( $data['bb_app_build_list']['data'] ) ) {
                foreach ( $data['bb_app_build_list']['data'] as $key => $value) {
                    if ( 'ios' === $value['type'] && 'live' === $value['env'] ) {
                        continue;
                    }
                    $install_url = \BuddyBossApp\Builds\Installer::instance()->get_installer_link( $value['id'] );
                    $data['bb_app_build_list']['data'][$key]['build_link'] = ( \BuddyBossApp\Library\Composer::instance()->qr_code_instance()->qr_code() )->render( $install_url );

                }
            }
		}

		return $data;
	}

    // /**
    //  * Get the app information.
	//  * @return array
	//  */
	// public function getAppInfo() {

	// 	$data['bb_app_center_info'] = array();

	// 	if( is_plugin_active( 'buddyboss-app/buddyboss-app.php' ) ) {
	// 		$data['bb_app_center_info'] = \BuddyBossApp\ManageApp::instance()->get_app_info();
	// 	}

	// 	return $data;
	// }
}
