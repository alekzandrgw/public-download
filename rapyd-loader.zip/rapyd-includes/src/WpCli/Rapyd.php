<?php

namespace Rapyd\WpCli;

use Rapyd\WpCore\WpCoreLoader;
use Rapyd\Sso\SsoUtils;

if (class_exists('WP_CLI_Command')) {
   
    /**
     * Rapyd Command Support for WordPress CLI.
     */
    class Rapyd extends \WP_CLI_Command
    {
        /**
         * Site Snapshot command.
         *
         * @param array $args Command arguments.
         * @param array $assoc_args Associative arguments.
         */
        public function siteSnapshot($args, $assoc_args)
        {
            // Fetch Snapshot data.
            $siteSnapShot = WpCoreLoader::instance()->GetPluginsThemesDetails();
            if ($siteSnapShot) {
                $result = [
                    'wp_details' => $siteSnapShot['wp_details'] ?? '',
                    'bb_details' => $siteSnapShot['bb_details'] ?? '',
                ];
                \WP_CLI::success(json_encode($result));
            }
        }

        /**
         * Secure SSO Authentication for Rapyd Platform.
         *
         * @param array $args
         * @param array $assoc_args
         * @return \WP_CLI::success|\WP_CLI::error
         */
        public function sso($args, $assoc_args)
        {

            $userEmail = isset($assoc_args['user_email']) ? $assoc_args['user_email'] : false;
            $user = false;

            // Capture the email if it's not given using parameters. 
            if (!$userEmail & isset($args[0]) && is_email($args[0])) {
                $userEmail = $args[0];
            }

            /**
             * Fetch the user from WordPress.
             */
            if ($userEmail) {
                $userId       = email_exists($userEmail);
                if ($userId) {
                    //echo "That E-mail is registered to user number " . $user_email;
                    $user = new \WP_User($userId);
                }
            }

            /**
             * If the user exists create the SSO.
             */
            if ($user) {
                $loginLink = SsoUtils::instance()->createLoginLink($user);
                // echo json_encode(["success" => true, "link" => $loginLink]);
                \WP_CLI::success(json_encode(["success" => true, "link" => $loginLink]));
            } else {
                $errorMsg = "No user found associated with {$userEmail}";
                // echo json_encode(["success" => false, "error" => $errorMsg]);
                \WP_CLI::error(json_encode(["success" => false, "error" => $errorMsg]));
            }
        }

        /**
         * Clear Cache Securely.
         *
         * @param array $args
         * @param array $assoc_args
         * @return \WP_CLI::success|\WP_CLI::error
         */
        public function flush($args, $assoc_args)
        {
            $cacheType = isset($args[0]) ? $args[0] : false;
            $flushed = false;

            if ($cacheType == "opcache") {
                if (function_exists('opcache_reset')) {
                    $flushed = true;
                    opcache_reset();
                }
            }

            if ($flushed) {
                \WP_CLI::success("{$cacheType} flushed");
            } else {
                \WP_CLI::error("Error flushing {$cacheType}");
            }
        }
    }
}
