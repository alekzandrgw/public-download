<?php

namespace Rapyd\WpCore;

use WP_Query;

class WpCoreLoader
{

    private static $instance;

    public function __construct()
    {
    }

    /**
     * Return the Instance.
     * @return WpCoreLoader
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class          = __CLASS__;
            self::$instance = new $class;
        }

        return self::$instance;
    }

    /**
     * Collect the WordPress Basic Information.
     * 
     * @return array
     */
    public function getSiteDetails()
    {
        $rapydSiteInfo['siteInfo'] = array(
            'blogName' => get_option('blogname'),
            'siteIcon' => get_site_icon_url(),
        );
        return $rapydSiteInfo;
    }


   /**
    * Collect the WordPress Server & Database Information.
    *
    * @return array
    */
    public function getServerDetails()
    {
        global $wp_version;
        $rapydSiteInfo['versions'] = array(
            'php'       => phpversion(),
            'wordpress' => $wp_version,
        );
        $rapydSiteInfo['db_info'] = array(
            'DB_USER'     => (defined('DB_USER')) ? DB_USER : '',
            'DB_PASSWORD' => (defined('DB_PASSWORD')) ? DB_PASSWORD : '',
            'DB_HOST'     => (defined('DB_HOST')) ? DB_HOST : '',
            'DB_NAME'     => (defined('DB_NAME')) ? DB_NAME : '',
            'WP_DEBUG'    => (defined('WP_DEBUG')) ? WP_DEBUG : ''
        );
        return $rapydSiteInfo;
    }

    /**
     * Collects the WordPress Plugins & Theme Information.
     * @return array
     */
    public function GetPluginsThemesDetails()
    {

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';

        $PluginsThemesInfo = array();
        // List all available plugins.
        $plugins        = get_plugins();
        $plugin_updates = get_plugin_updates();

        if (!empty($plugins)) {
            foreach ($plugins as $plugin_path => $plugin) {
                $plugin_part = (is_plugin_active($plugin_path)) ? 'active' : 'inactive';

                $pluginVersion          = $plugin['Version'];
                $pluginUpdateAvailable = 'none';
                $pluginUpdateVersion   = array();
                $updateVersion          = '';
                if (array_key_exists($plugin_path, $plugin_updates)) {
                    $pluginUpdateVersion[] =  $plugin_updates[$plugin_path]->update->new_version;
                    $pluginUpdateAvailable = 'available';
                    $updateVersion          = $plugin_updates[$plugin_path]->update->new_version;
                }
                $PluginsThemesInfo['plugins'][] = array(
                    'name'              => $plugin['Name'],
                    'status'            => $plugin_part,
                    'update'            => $pluginUpdateAvailable,
                    'version'           => $pluginVersion,
                    'title'             => $plugin['Name'],
                    'updateVersion'     => $updateVersion,
                    'isEditable'        => true,
                    'isUpdateAvailable' => ('available' === $pluginUpdateAvailable) ? true : false,
                    'updateList'        => $pluginUpdateVersion
                );
            }
        }

        $mu_plugins = get_mu_plugins();
        if (!empty($mu_plugins)) {
            foreach ($mu_plugins as $plugin) {
                $pluginVersion          = $plugin['Version'];
                $pluginUpdateAvailable = 'none';
                $pluginUpdateVersion   = array();
                $updateVersion          = '';
                $PluginsThemesInfo['plugins'][] = array(
                    'name'              => $plugin['Name'],
                    'status'            => 'active',
                    'update'            => $pluginUpdateAvailable,
                    'version'           => $pluginVersion,
                    'title'             => $plugin['Name'],
                    'updateVersion'     => $updateVersion,
                    'isEditable'        => false,
                    'isUpdateAvailable' => ('available' === $pluginUpdateAvailable) ? true : false,
                    'updateList'        => $pluginUpdateVersion
                );
            }
        }

        $dropinsPlugins = get_dropins();
        if (!empty($dropinsPlugins)) {
            foreach ($dropinsPlugins as $plugin) {
                $pluginVersion          = $plugin['Version'];
                $pluginUpdateAvailable = 'none';
                $pluginUpdateVersion   = array();
                $updateVersion          = '';
                $PluginsThemesInfo['plugins'][] = array(
                    'name'              => $plugin['Name'],
                    'status'            => 'active',
                    'update'            => $pluginUpdateAvailable,
                    'version'           => $pluginVersion,
                    'title'             => $plugin['Name'],
                    'updateVersion'     => $updateVersion,
                    'isEditable'        => false,
                    'isUpdateAvailable' => ('available' === $pluginUpdateAvailable) ? true : false,
                    'updateList'        => $pluginUpdateVersion
                );
            }
        }

        $activeTheme  = wp_get_theme();
        $themeUpdates = get_theme_updates();

        $activeThemeVersion       = $activeTheme->version;
        $activeThemeVersionDebug = $activeThemeVersion;
        // Populate a list of all themes available in the install.
        $allThemes = wp_get_themes();
        if (!empty($allThemes)) {
            foreach ($allThemes as $themeSlug => $theme) {

                $themeVersion = $theme->version;
                $themeUpdateAvailable = 'none';
                $themeUpdateVersion   = array();
                $updateVersion         = '';

                if (array_key_exists($themeSlug, $themeUpdates)) {

                    $themeUpdateVersion[] =  $themeUpdates[$themeSlug]->update['new_version'];
                    $themeUpdateAvailable = 'available';
                    $updateVersion          = $themeUpdates[$themeSlug]->update['new_version'];
                }

                $PluginsThemesInfo['themes'][] = array(
                    'name'              => $theme->Name,
                    'status'            => ($activeTheme->stylesheet === $themeSlug) ? 'active' : 'inactive',
                    'update'            => $themeUpdateAvailable,
                    'version'           => $themeVersion,
                    'title'             => $theme->Name,
                    'updateVersion'     => $updateVersion,
                    'isEditable'        => true,
                    'isUpdateAvailable' => ('available' === $themeUpdateAvailable) ? true : false,
                    'updateList'        => $themeUpdateVersion
                );
            }
        }

        global $wp_version;
        $activitiesCount = $groupsCount = $forumsCount = $forumDiscussionsCount = $forumRepliesCount = 0;

       /**
        * Get the platform activities count
        */
        if (function_exists('bp_activity_get')) {
            $activities       = bp_activity_get(
                array(
                    'display_comments' => false,
                    'count_total'      => true,
                    'show_hidden'      => true,
                    'fields'           => 'ids',
                    'per_page'         => -1,
                )
            );
            $activitiesCount = $activities['total'] ?? 0;
        }

        // Get Groups count.
        if (function_exists('bp_get_total_group_count')) {
            $groupsCount = bp_get_total_group_count();
        }

        /**
         * Get the forum counts.
         */
        $forumPostType = function_exists('bbp_get_forum_post_type') ? bbp_get_forum_post_type() : 'forum';
        $forumQuery     = new WP_Query(
            array(
                'post_type'           => $forumPostType,
                'post_parent'         => 'any',
                'post_status'         => 'publish',
                'posts_per_page'      => -1,
                'ignore_sticky_posts' => true,
            )
        );
        $forumsCount    = $forumQuery->found_posts ?? 0;

        /**
         * Get the forum topics counts.
         */
        $topicPostType         = function_exists('bbp_get_topic_post_type') ? bbp_get_topic_post_type() : 'topic';
        $topicQuery             = new WP_Query(
            array(
                'post_type'           => $topicPostType,
                'post_parent'         => 'any',
                'post_status'         => 'publish',
                'posts_per_page'      => -1,
                'ignore_sticky_posts' => true,
            )
        );
        $forumDiscussionsCount = $topicQuery->found_posts ?? 0;

        /**
         * Get the forum replies counts.
         */
        $reply_post_type     = function_exists('bbp_get_reply_post_type') ? bbp_get_reply_post_type() : 'replies';
        $repliesQuery       = new WP_Query(
            array(
                'post_type'           => $reply_post_type,
                'post_parent'         => 'any',
                'post_status'         => 'publish',
                'posts_per_page'      => -1,
                'ignore_sticky_posts' => true,
            )
        );
        $forumRepliesCount = $repliesQuery->found_posts ?? 0;

       /**
        * All WordPress Related Information.
        */
        $PluginsThemesInfo['wp_details'] = array(
            'wordpress_version' => $wp_version,
            'posts_total'       => wp_count_posts(),
            'users_total'       => count_users(),
            'themes_total'      => count($allThemes),
            'plugins_total'     => count($plugins) + count($mu_plugins) + count($dropinsPlugins),
        );

       /**
        * All BuddyBoss Related Information.
        */
        $PluginsThemesInfo['bb_details'] = array(
            'activities'        => (int) $activitiesCount,
            'groups'            => (int) $groupsCount,
            'forums'            => (int) $forumsCount,
            'forum_discussions' => (int) $forumDiscussionsCount,
            'forum_replies'     => (int) $forumRepliesCount,
        );

        return $PluginsThemesInfo;
    }
}
