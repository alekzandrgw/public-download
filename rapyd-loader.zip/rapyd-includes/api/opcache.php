<?php

/**
 * Do not edit.
 * Helper to get data of Zend OPcache for Rapyd Dashboard. 
 */

use Rapyd\Helper;

$sExtensionName = 'Zend OPcache';

if (!extension_loaded($sExtensionName)) {
    echo ("Error extension $sExtensionName not loaded");
    exit;
}

// Include Helper Class.
require dirname(__DIR__)."/src/Helper.php";

$opcache = opcache_get_status() ?? false;
if (isset($opcache['opcache_enabled'])) { //memory_usage, interned_strings_usage, opcache_statistics
    $status         = opcache_get_status();
    $config         = opcache_get_configuration();
    $missing_config = array_diff_key(ini_get_all('zend opcache', false), $config['directives']);
    if (!empty($missing_config)) {
        $config['directives'] = array_merge($config['directives'], $missing_config);
    }

    $result = array(
        'total_memory'      => formatBytes($config['directives']['opcache.memory_consumption']),
        'used_memory'       => formatBytes($status['memory_usage']['used_memory']),
        'free_memory'       => formatBytes($status['memory_usage']['free_memory']),
        'wasted_memory'     => formatBytes($status['memory_usage']['wasted_memory']),
        'last_restart_time' => (0 === $status['opcache_statistics']['last_restart_time']
            ? 'never'
            : gmdate('Y-m-d H:i:s', $status['opcache_statistics']['last_restart_time']))
    );
    $data = json_encode($result);

    // Encrypt as it's only intended for Rapyd to read.
    $data = Helper::instance()->encryptRapyd($data);
    echo json_encode($data);
    exit;

} else {
    echo "opcache is disabled";
}

/**
 * @param     $size
 * @param int $precision
 *
 * @return string
 */
function formatBytes($size, $precision = 2)
{
    $base     = log($size, 1024);
    $suffixes = array('', 'KB', 'MB', 'GB', 'TB');

    return round(pow(1024, $base - floor($base)), $precision) . ' ' . $suffixes[floor($base)];
}
