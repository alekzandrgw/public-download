<?php

use Rapyd\BbApp\BbAppLoader;
use Rapyd\BbAppCenter\AppCenterLoader;
use Rapyd\WpCore\WpCoreLoader;
use Rapyd\BbAppCenter\SsoLoader;
use Rapyd\Helper as Helper;
use Rapyd\Sso\SsoCliLoader;
use Rapyd\WpCli\Rapyd as WpCliRapyd;

if (!function_exists('add_action')) {
    echo "Security established, can\'t be assessed directly.";
    exit;
}

class Rapyd
{

    private static $instance;

    public function __construct()
    {
    }


    /**
     * @return Rapyd
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class          = __CLASS__;
            self::$instance = new $class;
            self::$instance->init(); // init
            self::$instance->hooks(); // run the hooks.
        }

        return self::$instance;
    }

    public function init()
    {

        SsoCliLoader::instance();
    }

    /**
     * WordPress Hooks
     *
     * @return void
     */
    public function hooks()
    {
        // Initialize WordPress.
        add_action('init', array($this, 'WpInit'));
        /**
         * Register the Cron Schedules.
         */
        add_action('cron_schedules', array($this, 'bbRapydCronSchedules'));
        add_action('bb_rapyd_cron_scheduler', array($this, 'bbRapydCronScheduler'));

        define("RAPYD_PLUGIN_URL", plugin_dir_url(__FILE__));
        define("RAPYD_PLUGIN_DIR", dirname(__FILE__));
    }

    /**
     * Callable via init WordPress Hook.
     */
    public function WpInit()
    {
        $this->bbRapydClearCron();
        
        $dir = RAPYD_PLUGIN_DIR . '/rapyd-json/';
        $bb_rapyd_update_log = $dir . 'rapyd-readymade.json';

        $filemtime = filemtime( $bb_rapyd_update_log );  // returns FALSE if file does not exist
        if ( ( time() - $filemtime ) >= 900 ) {
            $this->generateRapydJson();
        }
    }

    /**
     * Schedule Cronjob.
     *
     * @param $schedules
     *
     * @return mixed
     */
    function bbRapydCronSchedules($schedules)
    {

        $schedules['bb_rapyd_cron'] = array(
            'interval' => 5 * 60, // on every five min
            'display'  => 'On Every Five Min'
        );

        return $schedules;
    }

    /**
     * Clear Cronjob related to the Rapyd from WordPress.
     */
    function bbRapydClearCron()
    {
        if (!wp_next_scheduled('bb_rapyd_cron_scheduler')) {
            wp_schedule_event(time(), 'bb_rapyd_cron', 'bb_rapyd_cron_scheduler');
        }
    }

    /**
     * Run Every-min scheduler on WordPress.
     *
     * @return void
     */
    public function bbRapydCronScheduler()
    {
        $this->generateRapydJson();
    }

    /**
     * Prepare the Rapyd Data Collection File.
     * @throws Exception
     */
    function generateRapydJson()
    {

        $dir = RAPYD_PLUGIN_DIR . '/rapyd-json/';

        // Make sure directory exists.
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        $bb_rapyd_update_log = $dir . 'rapyd-readymade.json';
        if (file_exists($bb_rapyd_update_log)) {
            unlink($bb_rapyd_update_log);
        }


        // Create json file if doesn't exists.
        if (!file_exists($bb_rapyd_update_log)) {

            $fp = fopen($bb_rapyd_update_log, 'w');
            $bbAppLogData = WpCoreLoader::instance()->getSiteDetails();
            $bbAppLogData = array_merge($bbAppLogData, WpCoreLoader::instance()->getServerDetails());
            $bbAppLogData = array_merge($bbAppLogData, WpCoreLoader::instance()->GetPluginsThemesDetails());
            $bbAppLogData = array_merge($bbAppLogData, BbAppLoader::instance()->getAppInfo());
            $bbAppLogData = array_merge($bbAppLogData, BbAppLoader::instance()->getAppSettings());
            $bbAppLogData = array_merge($bbAppLogData, BbAppLoader::instance()->getAppleLocalDevices());
            $bbAppLogData = array_merge($bbAppLogData, BbAppLoader::instance()->getAppBuildList());
            $data = json_encode($bbAppLogData,JSON_PRETTY_PRINT);
            $data = Helper::instance()->encryptRapyd($data); // Encrypt the data securely.
            fwrite($fp, wp_json_encode($data));
            fclose($fp);
        }
    }


    
}
